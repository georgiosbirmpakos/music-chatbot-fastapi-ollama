import json
import logging
import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables.history import RunnableWithMessageHistory
from app.core.memory_store import get_memory
from app.services.downloader import download_song_list
from app.core.config import DEFAULT_MODEL_NAME
from app.services.playlist_operations import execute_playlist_operations
from pathlib import Path

# Load .env (make sure OPENAI_API_KEY is defined there)
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parents[2]  # adjust depth to the 'backend' root
with open(BASE_DIR / "prompts" / "suggest_songs_rag.txt", "r", encoding="utf-8") as f:
    system_prompt = f.read()


class ConversationalRagRecommender:
    def __init__(self, rag_chain, model_name: str = DEFAULT_MODEL_NAME):
        # Use OpenAI model (via ChatOpenAI)
        self.llm = ChatOpenAI(
            model=model_name,
            temperature=0,
            openai_api_key=os.getenv("OPENAI_API_KEY")
        )

        self.prompt = ChatPromptTemplate.from_messages([
            ("system", system_prompt),
            MessagesPlaceholder(variable_name="history"),
            ("human", "{input}")
        ])
        self.chain = RunnableWithMessageHistory(
            self.prompt | self.llm,
            get_session_history=get_memory,
            input_messages_key="input",
            history_messages_key="history"
        )
        self.song_memory = {}
        self.session_playlists = {}
        self.rag_chain = rag_chain

    def _extract_content(self, response):
        """Ensure compatibility with both chat messages and raw strings."""
        return response.content if hasattr(response, "content") else str(response)

    def detect_intent(self, message: str) -> str:
        prompt = f"""
Classify the user's intent into one of these categories:
- recommendation
- modify_playlist
- download
- other

User message: "{message}"
Respond with only one word: recommendation, modify_playlist, download, or other.
"""
        response = self.llm.invoke(prompt)
        return self._extract_content(response).strip().lower()

    def extract_constraints(self, message: str, current_playlist=None) -> dict:
        playlist_text = ""
        if current_playlist:
            playlist_text = "\n".join(f"{s['artist']} – {s['title']}" for s in current_playlist)
        prompt = f"""
You are analyzing a request to modify a music playlist. 
Here is the current playlist:
{playlist_text}

User message: "{message}"

Extract and return strict JSON:
{{
  "exclude_artists": [],
  "exclude_decades": [],
  "exclude_genres": [],
  "exclude_moods": []
}}
"""
        response = self.llm.invoke(prompt)
        try:
            return json.loads(self._extract_content(response))
        except json.JSONDecodeError:
            return {"exclude_artists": [], "exclude_decades": [], "exclude_genres": [], "exclude_moods": []}

    def convert_rag_to_struct(self, rag_result: str) -> list:
        structured = []
        for line in rag_result.splitlines():
            if " – " in line:
                try:
                    _, rest = line.split(". ", 1)
                    artist, title_decade = rest.split(" – ", 1)
                    title, decade = title_decade.rsplit("(", 1)
                    structured.append({
                        "artist": artist.strip(),
                        "title": title.strip(),
                        "decade": decade.replace(")", "").strip(),
                        "genre": "unknown",
                        "mood": "unknown"
                    })
                except ValueError:
                    continue
        return structured

    def format_playlist(self, playlist: list) -> str:
        return "\n".join(f"{i+1}. {s['artist']} – {s['title']} ({s['decade']})" for i, s in enumerate(playlist))

    def ask(self, user_message: str, session_id: str = "default") -> str:
        intent = self.detect_intent(user_message)
        if intent == "recommendation":
            rag_result = self.rag_chain.recommend_songs(user_message, top_k=10)
            playlist = self.convert_rag_to_struct(rag_result)
            self.session_playlists[session_id] = playlist
            self.song_memory[session_id] = [f"{s['artist']} – {s['title']}" for s in playlist]
            return self.format_playlist(playlist)
        if intent == "modify_playlist":
            if session_id not in self.session_playlists:
                return "⚠️ No playlist to modify yet."
            operations = self.extract_operations(user_message, session_id=session_id)
            updated_playlist = execute_playlist_operations(
                self.session_playlists[session_id],
                operations,
                self.rag_chain
            )
            self.session_playlists[session_id] = updated_playlist
            self.song_memory[session_id] = [f"{s['artist']} – {s['title']}" for s in updated_playlist]
            return self.format_playlist(updated_playlist)
        if intent == "download":
            songs = self.song_memory.get(session_id)
            if not songs:
                return "⚠️ No songs to download for this session."
            paths = download_song_list(songs, session_id=session_id)
            return "✅ Downloaded songs:\n" + "\n".join(paths)
        # fallback to generic chat
        response = self.rag_chain.chat(user_message)
        return response if isinstance(response, str) else self._extract_content(response)

    def extract_operations(self, message: str, session_id: str = "default") -> dict:
        with open(os.path.join("prompts", "playlist_operations_prompt.txt"), "r", encoding="utf-8") as f:
            operations_prompt = f.read()

        playlist_len = len(self.session_playlists.get(session_id, []))
        full_prompt = (
            f"{operations_prompt}\n\n"
            f"Current playlist length: {playlist_len}\n"
            f"User instruction:\n{message}\n"
            "Output only JSON."
        )

        response = self.llm.invoke(full_prompt)
        raw_output = response.content if hasattr(response, "content") else str(response)

        try:
            return json.loads(raw_output)
        except json.JSONDecodeError:
            return {"operations": []}
