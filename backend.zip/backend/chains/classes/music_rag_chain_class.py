# backend/chains/classes/music_rag_chain_class.py
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.docstore.document import Document

class MusicRAGChain:
    def __init__(self, music_data: list[str], model_name: str):
        self.embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
        self.vectorstore = FAISS.from_documents(
            [Document(page_content=text) for text in music_data], self.embeddings
        )

    def recommend_songs(self, query: str, top_k: int = 5):
        docs = self.vectorstore.similarity_search(query, k=top_k * 5)
        seen, results = set(), []
        for doc in docs:
            parts = dict(item.split(": ", 1) for item in doc.page_content.split(" | "))
            key = (parts.get("Title"), parts.get("Artist"))
            if key not in seen:
                seen.add(key)
                results.append(parts)
            if len(results) >= top_k:
                break
        return "\n".join(f"{i+1}. {s['Artist']} – {s['Title']} ({s['Decade']})" for i, s in enumerate(results))
