from chains.classes.conversational_rag_recommender_class import ConversationalRagRecommender
from chains.music_rag_chain import rag_chain

recommender = ConversationalRagRecommender(rag_chain)
