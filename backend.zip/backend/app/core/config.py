# Most reliable model
DEFAULT_MODEL_NAME = "gpt-4o-mini"
